# csgo-personal-data-collector
This is a PyQt powered GUI based application which will be used to collect Valve Counter Strike:Global Offensive Competitive Matchmaking data according to the GDPR Act.

